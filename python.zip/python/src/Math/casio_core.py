"""
Small shared maths core used by the standalone CASIO programs.

The full programs still own their exam-style output, but this file keeps the
common parser, normaliser, equivalence checks, and a few reusable integration
patterns in one place.  It deliberately stays dependency-light so the same
ideas can be copied into the calculator build when needed.
"""

try:
    import math
except ImportError:
    math = None

GCD = math.gcd if math is not None and hasattr(math, "gcd") else None

E = ("const", "e")
PI = ("const", "pi")

FUNC_NAMES = (
    "sin", "cos", "tan", "sec", "cosec", "cot",
    "exp", "log", "log10", "sqrt", "abs", "ln",
    "atan", "asin", "acos", "sinh", "cosh", "tanh",
)
FUNC_ALIASES = {
    "ln": "log",
    "csc": "cosec",
    "arcsin": "asin",
    "arccos": "acos",
    "arctan": "atan",
}


_SUPERSCRIPT_DIGITS = {
    "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
    "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
    "⁻": "-", "⁺": "+",
}


def normalize_text(text):
    """Turn friendly calculator input into the ASCII syntax the parser expects."""
    if not isinstance(text, str):
        return text
    text = text.strip()
    # Normalise symbols students actually type before the tokenizer sees them.
    # Keeping this here means every program accepts the same pi, degree, root,
    # fraction, and absolute-value spellings.
    for pair in (
        ("−", "-"), ("–", "-"), ("—", "-"),
        ("×", "*"), ("∗", "*"), ("⋅", "*"),
        ("÷", "/"), ("⁄", "/"),
        ("π", "pi"), ("Π", "pi"), ("°", ""),
        ("½", "(1/2)"), ("¼", "(1/4)"), ("¾", "(3/4)"),
    ):
        text = text.replace(pair[0], pair[1])
    text = _normalize_superscripts(text)
    text = _normalize_inverse_trig_notation(text)
    text = _normalize_sqrt_symbol(text)
    if "|" in text:
        text = _normalize_function_pipe_calls(text)
        text = _convert_abs_pipes(text)
    text = _normalize_compact_function_words(text)
    return text


def _normalize_superscripts(text):
    """Convert x², x⁻¹, etc. into x^2 style tokens."""
    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in _SUPERSCRIPT_DIGITS:
            run = []
            while i < len(text) and text[i] in _SUPERSCRIPT_DIGITS:
                run.append(_SUPERSCRIPT_DIGITS[text[i]])
                i += 1
            out.append("^" + "".join(run))
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _is_digit_char(ch):
    return "0" <= ch <= "9"


def _is_alpha_char(ch):
    return ("A" <= ch <= "Z") or ("a" <= ch <= "z")


def _is_name_start(ch):
    return _is_alpha_char(ch) or ch == "_"


def _is_name_char(ch):
    return _is_name_start(ch) or _is_digit_char(ch)


def _normalize_sqrt_symbol(text):
    """Accept both sqrt(x) and the calculator-style root symbol."""
    if "√" not in text:
        return text
    out = []
    i = 0
    while i < len(text):
        if text[i] != "√":
            out.append(text[i])
            i += 1
            continue
        i += 1
        while i < len(text) and text[i] in " \t":
            i += 1
        if i < len(text) and text[i] == "(":
            out.append("sqrt")
            continue
        start = i
        if i < len(text) and (_is_name_start(text[i]) or _is_digit_char(text[i]) or text[i] == "."):
            i += 1
            while i < len(text) and (_is_name_char(text[i]) or text[i] == "."):
                i += 1
            out.append("sqrt(" + text[start:i] + ")")
        else:
            out.append("sqrt")
    return "".join(out)


def _previous_significant_char(text, index):
    i = index - 1
    while i >= 0:
        ch = text[i]
        if ch not in " \t\r\n":
            return ch
        i -= 1
    return None


def _should_open_abs_pipe(text, index):
    prev = _previous_significant_char(text, index)
    if prev is None:
        return True
    return prev in "([{,+-*/^=<>"


def _convert_abs_pipes(text):
    """Translate |x| into abs(x), while leaving malformed pipes untouched."""
    if text.count("|") % 2 != 0:
        return text
    out = []
    depth = 0
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "|":
            if depth == 0 or _should_open_abs_pipe(text, i):
                out.append("abs(")
                depth += 1
            else:
                out.append(")")
                depth -= 1
        else:
            out.append(ch)
        i += 1
    if depth != 0:
        return text
    return "".join(out)


_COMPACT_FUNC_WORDS = (
    "arcsin", "arccos", "arctan",
    "cosec",
    "asin", "acos", "atan",
    "sinh", "cosh", "tanh",
    "sqrt", "sin", "cos", "tan", "sec", "cot",
    "abs", "exp", "log", "ln", "csc",
)


def _normalize_inverse_trig_notation(text):
    """Map common inverse trig spellings onto the internal asin/acos/atan names."""
    pairs = (
        ("arcsin^-1", "asin"),
        ("arccos^-1", "acos"),
        ("arctan^-1", "atan"),
        ("sin**-1", "asin"),
        ("cos**-1", "acos"),
        ("tan**-1", "atan"),
        ("sin^-1", "asin"),
        ("cos^-1", "acos"),
        ("tan^-1", "atan"),
    )
    i = 0
    while i < len(pairs):
        text = text.replace(pairs[i][0], pairs[i][1])
        i += 1
    return text


def _split_compact_function_word(word):
    low = word.lower()
    if low in _COMPACT_FUNC_WORDS or low in ("pi", "e"):
        return None, None
    i = 0
    while i < len(_COMPACT_FUNC_WORDS):
        token = _COMPACT_FUNC_WORDS[i]
        if low.startswith(token) and len(word) > len(token):
            rest = word[len(token):]
            name = token
            if name == "ln":
                name = "log"
            elif name == "csc":
                name = "cosec"
            return name, rest
        i += 1
    return None, None


def _normalize_compact_function_words(text):
    """Accept compact forms like sinx by expanding them to sin(x)."""
    out = []
    i = 0
    while i < len(text):
        ch = text[i]
        if _is_name_start(ch):
            j = i + 1
            while j < len(text) and _is_name_char(text[j]):
                j += 1
            word = text[i:j]
            name, rest = _split_compact_function_word(word)
            if name is not None:
                out.append(name)
                out.append("(")
                out.append(_normalize_compact_function_words(rest))
                out.append(")")
            else:
                out.append(word)
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _normalize_function_pipe_calls(text):
    out = []
    i = 0
    while i < len(text):
        matched = False
        j = 0
        while j < len(_COMPACT_FUNC_WORDS):
            token = _COMPACT_FUNC_WORDS[j]
            end = i + len(token)
            if text[i:end].lower() == token:
                prev_ok = i == 0 or not _is_name_char(text[i - 1])
                if prev_ok and end < len(text) and text[end] == "|":
                    close = end + 1
                    while close < len(text) and text[close] != "|":
                        close += 1
                    if close < len(text):
                        out.append(text[i:end])
                        out.append("(")
                        out.append(text[end:close + 1])
                        out.append(")")
                        i = close + 1
                        matched = True
                        break
            j += 1
        if matched:
            continue
        out.append(text[i])
        i += 1
    return "".join(out)


def _gcd(a, b):
    if a < 0:
        a = -a
    if b < 0:
        b = -b
    if GCD is not None:
        return GCD(a, b)
    while b:
        a, b = b, a % b
    return a or 1


def num(a, b=1):
    if b == 0:
        raise ZeroDivisionError("zero denominator")
    if b < 0:
        a = -a
        b = -b
    g = _gcd(int(a), int(b))
    return ("num", int(a) // g, int(b) // g)


def num_text(text):
    if "." not in text:
        return num(int(text), 1)
    whole, frac = text.split(".", 1)
    if whole == "":
        whole = "0"
    scale = 10 ** len(frac)
    sign = -1 if whole[:1] == "-" else 1
    value = abs(int(whole)) * scale + int(frac or "0")
    return num(sign * value, scale)


def sym(name):
    return ("sym", name)


def is_num(node):
    return isinstance(node, tuple) and len(node) > 0 and node[0] == "num"


def is_one(node):
    return is_num(node) and node[1] == node[2]


def is_zero(node):
    return is_num(node) and node[1] == 0


def is_minus_one(node):
    return is_num(node) and node[1] == -node[2]


def is_int_num(node):
    return is_num(node) and node[2] == 1


def addq(a, b):
    return num(a[1] * b[2] + b[1] * a[2], a[2] * b[2])


def mulq(a, b):
    return num(a[1] * b[1], a[2] * b[2])


def divq(a, b):
    return num(a[1] * b[2], a[2] * b[1])


def negq(a):
    return num(-a[1], a[2])


def flat(node, kind):
    if node[0] != kind:
        return [node]
    out = []
    for item in node[1]:
        if item[0] == kind:
            out.extend(flat(item, kind))
        else:
            out.append(item)
    return out


def make_add(parts):
    out = []
    const = num(0)
    for item in parts:
        item = simplify(item)
        if item[0] == "add":
            for child in item[1]:
                out.append(child)
        elif is_num(item):
            const = addq(const, item)
        elif is_zero(item):
            pass
        else:
            out.append(item)
    if not is_zero(const):
        out.append(const)
    if len(out) == 0:
        return num(0)
    if len(out) == 1:
        return out[0]
    return ("add", tuple(out))


def make_mul(parts):
    out = []
    const = num(1)
    for item in parts:
        item = simplify(item)
        if item[0] == "mul":
            for child in item[1]:
                out.append(child)
        elif is_num(item):
            const = mulq(const, item)
        else:
            out.append(item)
    if is_zero(const):
        return num(0)
    if not is_one(const):
        out.insert(0, const)
    if len(out) == 0:
        return num(1)
    if len(out) == 1:
        return out[0]
    return ("mul", tuple(out))


def add(parts):
    return simplify(make_add(parts))


def mul(parts):
    return simplify(make_mul(parts))


def div(a, b):
    return simplify(("div", a, b))


def power(a, b):
    return simplify(("pow", a, b))


def fn(name, arg):
    if name == "ln":
        name = "log"
    if name == "csc":
        name = "cosec"
    if name == "exp":
        return power(E, arg)
    return simplify(("fn", name, arg))


def neg(node):
    if is_num(node):
        return negq(node)
    return mul([num(-1), node])


def sub(a, b):
    return add([a, neg(b)])


def log_abs(node):
    return fn("log", fn("abs", node))


def simplify(node):
    if node is None:
        return None
    kind = node[0]
    if kind in ("num", "sym", "const"):
        return node
    if kind == "fn":
        name = node[1]
        if name == "ln":
            name = "log"
        if name == "csc":
            name = "cosec"
        if name == "exp":
            return simplify(("pow", E, simplify(node[2])))
        return ("fn", name, simplify(node[2]))
    if kind == "pow":
        base = simplify(node[1])
        exp = simplify(node[2])
        if is_zero(exp):
            return num(1)
        if is_one(exp):
            return base
        if is_num(base) and is_int_num(exp):
            p = exp[1]
            if p >= 0:
                return num(base[1] ** p, base[2] ** p)
            p = -p
            return num(base[2] ** p, base[1] ** p)
        if base[0] == "pow" and is_num(base[2]) and is_num(exp):
            return power(base[1], mulq(base[2], exp))
        return ("pow", base, exp)
    if kind == "div":
        top = simplify(node[1])
        bot = simplify(node[2])
        if is_zero(top):
            return num(0)
        if is_one(bot):
            return top
        if is_num(top) and is_num(bot):
            return divq(top, bot)
        if bot[0] == "pow" and is_num(bot[2]):
            return simplify(("mul", (top, ("pow", bot[1], negq(bot[2])))))
        return ("div", top, bot)
    if kind == "add":
        return make_add(node[1])
    if kind == "mul":
        return make_mul(node[1])
    return node


def depends(node, name):
    kind = node[0]
    if kind == "sym":
        return node[1] == name
    if kind in ("num", "const"):
        return False
    if kind == "fn":
        return depends(node[2], name)
    if kind in ("pow", "div"):
        return depends(node[1], name) or depends(node[2], name)
    for child in node[1]:
        if depends(child, name):
            return True
    return False


def sig(node):
    kind = node[0]
    if kind in ("num", "sym", "const"):
        return node
    if kind == "fn":
        return ("fn", node[1], sig(node[2]))
    if kind in ("pow", "div"):
        return (kind, sig(node[1]), sig(node[2]))
    parts = []
    for child in flat(node, kind):
        parts.append(sig(child))
    parts.sort(key=repr)
    return (kind, tuple(parts))


def same(a, b):
    return a == b or sig(simplify(a)) == sig(simplify(b))


def _prec(node):
    kind = node[0]
    if kind == "add":
        return 1
    if kind in ("mul", "div"):
        return 2
    if kind == "pow":
        return 3
    return 4


def _num_text(node):
    if node[2] == 1:
        return str(node[1])
    return str(node[1]) + "/" + str(node[2])


def format_expr(node, parent=0):
    node = simplify(node)
    kind = node[0]
    if kind == "num":
        return _num_text(node)
    if kind == "sym":
        return node[1]
    if kind == "const":
        return node[1]
    if kind == "fn":
        return node[1] + "(" + format_expr(node[2]) + ")"
    if kind == "pow":
        if same(node[1], E):
            text = "e^(" + format_expr(node[2]) + ")"
        else:
            text = format_expr(node[1], 3) + "^" + format_expr(node[2], 3)
        return "(" + text + ")" if _prec(node) < parent else text
    if kind == "div":
        text = format_expr(node[1], 2) + "/" + format_expr(node[2], 3)
        return "(" + text + ")" if _prec(node) < parent else text
    if kind == "mul":
        parts = []
        for item in flat(node, "mul"):
            parts.append(format_expr(item, 2))
        text = "*".join(parts)
        return "(" + text + ")" if _prec(node) < parent else text
    if kind == "add":
        parts = []
        for item in flat(node, "add"):
            if item[0] == "num" and item[1] < 0:
                parts.append("- " + _num_text(num(-item[1], item[2])))
            elif item[0] == "mul" and len(item[1]) > 0 and is_num(item[1][0]) and item[1][0][1] < 0:
                rest = make_mul((num(-item[1][0][1], item[1][0][2]),) + item[1][1:])
                parts.append("- " + format_expr(rest, 1))
            else:
                if parts:
                    parts.append("+ " + format_expr(item, 1))
                else:
                    parts.append(format_expr(item, 1))
        text = " ".join(parts)
        return "(" + text + ")" if _prec(node) < parent else text
    return repr(node)


def parse_expr(text):
    """Parse a normalised expression into the tuple AST used across the project."""
    text = normalize_text(text)
    tokens = []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in " \t\r\n":
            i += 1
        elif text[i:i + 2] == "**":
            tokens.append("**")
            i += 2
        elif ch in "()+-*/^=,":
            tokens.append(ch)
            i += 1
        elif ch.isdigit() or (ch == "." and i + 1 < len(text) and text[i + 1].isdigit()):
            j = i + 1
            dots = 1 if ch == "." else 0
            while j < len(text) and (text[j].isdigit() or text[j] == "."):
                if text[j] == ".":
                    dots += 1
                j += 1
            if dots > 1:
                raise ValueError("Bad number.")
            tokens.append(text[i:j])
            i = j
        elif ch.isalpha() or ch == "_":
            j = i + 1
            while j < len(text) and (text[j].isalnum() or text[j] == "_"):
                j += 1
            tokens.append(text[i:j])
            i = j
        else:
            raise ValueError("Unexpected character: " + ch)

    pos = [0]

    def peek():
        if pos[0] >= len(tokens):
            return None
        return tokens[pos[0]]

    def take(tok=None):
        cur = peek()
        if tok is not None and cur != tok:
            raise ValueError("Expected " + repr(tok) + " but found " + repr(cur))
        pos[0] += 1
        return cur

    def starts_atom(tok):
        # This is what gives us implicit multiplication: 2x, x(x+1),
        # and sin x all become ordinary ASTs without asking users for '*'.
        if tok is None:
            return False
        if tok == "(":
            return True
        return tok not in ("+", "-", "*", "/", "^", "**", ")", ",", "=")

    def atom_ok(tok):
        if tok is None:
            return False
        if tok in ("+", "-", "*", "/", "^", "**", ")", ",", "="):
            return False
        return True

    def consume_func_arg():
        if peek() == "(":
            take("(")
            out = parse_add()
            take(")")
            return out
        if starts_atom(peek()):
            return parse_atom()
        raise ValueError("Bad function form.")

    def parse_atom():
        tok = peek()
        if tok == "(":
            take("(")
            out = parse_add()
            take(")")
            return out
        if not atom_ok(tok):
            raise ValueError("Bad token: " + repr(tok))
        take()
        if tok[0].isdigit() or tok[0] == ".":
            return num_text(tok)
        name = tok.lower()
        if name in FUNC_ALIASES:
            name = FUNC_ALIASES[name]
        if name == "pi":
            return PI
        if name == "e":
            return E
        if name in FUNC_NAMES:
            # Functions can be written as sin(x), sin x, or sin^2(x).  The
            # exponent-before-argument branch handles the last exam shorthand.
            if peek() in ("^", "**"):
                take(peek())
                exp = parse_unary()
                return power(fn(name, consume_func_arg()), exp)
            if peek() == "(":
                take("(")
                arg = parse_add()
                if peek() == ",":
                    take(",")
                    arg2 = parse_add()
                    take(")")
                    if name == "log":
                        return div(fn("log", arg2), fn("log", arg))
                    return fn(name, mul([arg, arg2]))
                take(")")
                return fn(name, arg)
            if starts_atom(peek()):
                return fn(name, parse_atom())
        return sym(tok)

    def parse_power():
        out = parse_atom()
        if peek() in ("^", "**"):
            take(peek())
            out = power(out, parse_unary())
        return out

    def parse_unary():
        if peek() == "-":
            take("-")
            return neg(parse_unary())
        return parse_power()

    def parse_mul():
        out = parse_unary()
        while True:
            tok = peek()
            if tok == "*":
                take("*")
                out = mul([out, parse_unary()])
            elif tok == "/":
                take("/")
                out = div(out, parse_unary())
            elif starts_atom(tok):
                out = mul([out, parse_unary()])
            else:
                return out

    def parse_add():
        out = parse_mul()
        while peek() in ("+", "-"):
            if peek() == "+":
                take("+")
                out = add([out, parse_mul()])
            else:
                take("-")
                out = add([out, neg(parse_mul())])
        return out

    result = parse_add()
    if pos[0] != len(tokens):
        raise ValueError("Unexpected token: " + repr(peek()))
    return simplify(result)


def _split_num_coeff(node):
    node = simplify(node)
    if is_num(node):
        return node, num(1)
    if node[0] == "mul":
        coeff = num(1)
        rest = []
        for item in node[1]:
            if is_num(item):
                coeff = mulq(coeff, item)
            else:
                rest.append(item)
        return coeff, make_mul(rest)
    return num(1), node


def _reciprocal_power_coeff(node, var, positive_power):
    coeff, rest = _split_num_coeff(node)
    x = sym(var)
    if positive_power == 1 and rest[0] == "div" and is_one(rest[1]) and same(rest[2], x):
        return coeff
    if rest[0] == "div" and is_one(rest[1]):
        den = rest[2]
        if den[0] == "pow" and same(den[1], x) and is_int_num(den[2]) and den[2][1] == positive_power:
            return coeff
    if rest[0] == "pow" and same(rest[1], x) and is_int_num(rest[2]) and rest[2][1] == -positive_power:
        return coeff
    return None


def _is_exp_reciprocal(node, var):
    node = simplify(node)
    if node[0] == "fn" and node[1] == "exp":
        arg = node[2]
    elif node[0] == "pow" and same(node[1], E):
        arg = node[2]
    else:
        return None
    coeff = _reciprocal_power_coeff(arg, var, 1)
    if coeff is None:
        return None
    return coeff


def _find_exp_reciprocal_case(node, var):
    """Detect e^(c/x)*(A/x^2 + B/x^3), a useful substitution pattern."""
    node = simplify(node)
    factors = flat(node, "mul") if node[0] == "mul" else [node]
    exp_index = -1
    c = None
    i = 0
    while i < len(factors):
        c_try = _is_exp_reciprocal(factors[i], var)
        if c_try is not None:
            exp_index = i
            c = c_try
            break
        i += 1
    if exp_index < 0 or is_zero(c):
        return None
    rest = make_mul(factors[:exp_index] + factors[exp_index + 1:])
    terms = flat(rest, "add") if rest[0] == "add" else [rest]
    coeff2 = num(0)
    coeff3 = num(0)
    for term in terms:
        c2 = _reciprocal_power_coeff(term, var, 2)
        c3 = _reciprocal_power_coeff(term, var, 3)
        if c2 is not None:
            coeff2 = addq(coeff2, c2)
        elif c3 is not None:
            coeff3 = addq(coeff3, c3)
        elif not is_zero(term):
            return None
    if is_zero(coeff2) and is_zero(coeff3):
        return None
    return c, coeff2, coeff3


def _clean_work_expr(text):
    text = text.replace("-1*u", "-u")
    text = text.replace("1*u", "u")
    return text


def integrate_reciprocal_exp(node, var, forced_u=None):
    """Integrate reciprocal-exponential forms by the substitution u = c/x."""
    data = _find_exp_reciprocal_case(node, var)
    if data is None:
        return None
    c, coeff2, coeff3 = data
    if forced_u is not None and not same(simplify(forced_u), div(num(1), sym(var))):
        if not same(simplify(forced_u), div(c, sym(var))):
            return None
    x = sym(var)
    u_expr = div(c, x)
    exp_part = power(E, u_expr)
    one_over_c = divq(num(1), c)
    one_over_c2 = divq(num(1), mulq(c, c))
    const_part = addq(negq(mulq(coeff2, one_over_c)), mulq(coeff3, one_over_c2))
    x_part = neg(div(mul([coeff3, exp_part]), mul([c, x]))) if not is_zero(coeff3) else num(0)
    ans = add([mul([const_part, exp_part]), x_part])
    if is_zero(const_part):
        ans = x_part
    if same(c, num(1)):
        du_text = "-1/" + var + "^2"
        dx_text = "-x^2 du"
        power_text = "x = 1/u, so 1/" + var + "^2 = u^2 and 1/" + var + "^3 = u^3."
    else:
        du_text = "-" + format_expr(c) + "/" + var + "^2"
        dx_text = "-" + var + "^2/" + format_expr(c) + " du"
        power_text = (
            var + " = " + format_expr(c) + "/u, so 1/" + var + "^2 = u^2/"
            + format_expr(mulq(c, c)) + " and 1/" + var + "^3 = u^3/"
            + format_expr(mulq(mulq(c, c), c)) + "."
        )
    A = negq(mulq(coeff2, one_over_c))
    B = negq(mulq(coeff3, one_over_c2))
    u = sym("u")
    u_integrand = mul([add([A, mul([B, u])]), power(E, u)])
    u_answer = mul([add([addq(A, negq(B)), mul([B, u])]), power(E, u)])
    lines = [
        "u = " + format_expr(u_expr),
        "du/d" + var + " = " + du_text + ", so d" + var + " = " + dx_text + ".",
        power_text,
        "I = Int[" + _clean_work_expr(format_expr(u_integrand)) + "] du.",
        "Use Int[(A + B*u)e^u] du = (A + B*(u - 1))*e^u.",
        "= " + _clean_work_expr(format_expr(u_answer)) + " + C.",
        "Substitute u = " + format_expr(u_expr) + ".",
    ]
    return "sub", simplify(ans), lines


def substitution_candidates(node, var, mode):
    """Return suggested u-substitutions that other programs can surface."""
    out = []
    data = _find_exp_reciprocal_case(node, var)
    if data is not None:
        c = data[0]
        out.append(div(c, sym(var)))
        if not same(c, num(1)):
            out.append(div(num(1), sym(var)))
    return out


def _match_trig_sum_den(den):
    den = simplify(den)
    if den[0] != "add":
        return None
    parts = flat(den, "add")
    if len(parts) != 2:
        return None
    left = parts[0]
    right = parts[1]
    if left[0] != "fn" or right[0] != "fn":
        return None
    if not same(left[2], right[2]):
        return None
    names = (left[1], right[1])
    if names == ("tan", "sec") or names == ("sec", "tan"):
        return "tan_sec", left[2]
    if names == ("cot", "cosec") or names == ("cosec", "cot"):
        return "cot_cosec", left[2]
    return None


def _extract_outer_and_trig(top, arg, names):
    top = simplify(top)
    factors = flat(top, "mul") if top[0] == "mul" else [top]
    found = None
    rest = []
    for item in factors:
        if found is None and item[0] == "fn" and item[1] in names and same(item[2], arg):
            found = item[1]
        else:
            rest.append(item)
    if found is None:
        return None
    return make_mul(rest), found


def _outer_kind(outer, var):
    outer = simplify(outer)
    if is_one(outer):
        return num(1), "one"
    coeff, rest = _split_num_coeff(outer)
    if same(rest, sym(var)):
        return coeff, "x"
    return None


def integrate_trig_conjugate_ratio(node, var):
    node = simplify(node)
    if node[0] != "div":
        return None
    den = _match_trig_sum_den(node[2])
    if den is None:
        return None
    family, arg = den
    if not same(arg, sym(var)):
        return None
    if family == "tan_sec":
        data = _extract_outer_and_trig(node[1], arg, ("tan", "sec"))
    else:
        data = _extract_outer_and_trig(node[1], arg, ("cot", "cosec"))
    if data is None:
        return None
    outer, trig_name = data
    outer_data = _outer_kind(outer, var)
    if outer_data is None:
        return None
    coeff, outer_type = outer_data
    x = sym(var)
    if family == "tan_sec":
        sec = fn("sec", arg)
        tan = fn("tan", arg)
        sin = fn("sin", arg)
        if trig_name == "tan":
            v = add([sec, neg(tan)])
            primitive_v = log_abs(add([num(1), sin]))
            if outer_type == "one":
                base = add([x, v])
                explain = "Use tan(A)/(tan(A)+sec(A)) = 1 + d(sec(A)-tan(A))/dA."
            else:
                base = add([div(power(x, num(2)), num(2)), mul([x, v]), neg(primitive_v)])
                explain = "Use tan(A)/(tan(A)+sec(A)) = 1 + d(sec(A)-tan(A))/dA, then integrate by parts."
        else:
            v = add([tan, neg(sec)])
            primitive_v = log_abs(add([num(1), sin]))
            if outer_type == "one":
                base = v
                explain = "Use sec(A)/(tan(A)+sec(A)) = d(tan(A)-sec(A))/dA."
            else:
                base = add([mul([x, v]), primitive_v])
                explain = "Use sec(A)/(tan(A)+sec(A)) = d(tan(A)-sec(A))/dA, then integrate by parts."
    else:
        cot = fn("cot", arg)
        csc = fn("cosec", arg)
        sin = fn("sin", arg)
        primitive_cot = log_abs(sin)
        primitive_csc = log_abs(add([csc, neg(cot)]))
        if trig_name == "cot":
            v = add([cot, neg(csc)])
            primitive_v = add([primitive_cot, neg(primitive_csc)])
            if outer_type == "one":
                base = add([x, v])
                explain = "Use cot(A)/(cot(A)+cosec(A)) = 1 + d(cot(A)-cosec(A))/dA."
            else:
                base = add([div(power(x, num(2)), num(2)), mul([x, v]), neg(primitive_v)])
                explain = "Use cot(A)/(cot(A)+cosec(A)) = 1 + d(cot(A)-cosec(A))/dA, then integrate by parts."
        else:
            v = add([csc, neg(cot)])
            primitive_v = add([primitive_csc, neg(primitive_cot)])
            if outer_type == "one":
                base = v
                explain = "Use cosec(A)/(cot(A)+cosec(A)) = d(cosec(A)-cot(A))/dA."
            else:
                base = add([mul([x, v]), neg(primitive_v)])
                explain = "Use cosec(A)/(cot(A)+cosec(A)) = d(cosec(A)-cot(A))/dA, then integrate by parts."
    ans = simplify(mul([coeff, base]))
    return "trig", ans, [
        explain,
        "So I = Int[" + format_expr(mul([coeff, base if outer_type == "one" else node])) + "] d" + var,
    ]


def tree_size(node):
    kind = node[0]
    if kind in ("num", "sym", "const"):
        return 1
    if kind == "fn":
        return 1 + tree_size(node[2])
    if kind in ("pow", "div"):
        return 1 + tree_size(node[1]) + tree_size(node[2])
    total = 1
    for child in node[1]:
        total += tree_size(child)
    return total


def _mul_distribute_once(node, limit):
    node = simplify(node)
    if node[0] != "mul":
        return node
    factors = []
    for item in flat(node, "mul"):
        factors.append(expand_small(item, limit))
    terms = [num(1)]
    for factor in factors:
        next_terms = []
        items = flat(factor, "add") if factor[0] == "add" else [factor]
        if len(terms) * len(items) > limit:
            return simplify(("mul", tuple(factors)))
        i = 0
        while i < len(terms):
            j = 0
            while j < len(items):
                next_terms.append(mul([terms[i], items[j]]))
                j += 1
            i += 1
        terms = next_terms
    return add(terms)


def expand_small(node, limit=64):
    node = simplify(node)
    kind = node[0]
    if kind in ("num", "sym", "const"):
        return node
    if kind == "fn":
        return fn(node[1], expand_small(node[2], limit))
    if kind == "div":
        return div(expand_small(node[1], limit), expand_small(node[2], limit))
    if kind == "add":
        return add([expand_small(item, limit) for item in flat(node, "add")])
    if kind == "mul":
        return _mul_distribute_once(node, limit)
    if kind == "pow":
        base = expand_small(node[1], limit)
        exp = simplify(node[2])
        if is_int_num(exp) and 2 <= exp[1] <= 6 and tree_size(base) <= 28:
            cur = num(1)
            i = 0
            while i < exp[1]:
                cur = expand_small(mul([cur, base]), limit)
                if tree_size(cur) > limit * 4:
                    return power(base, exp)
                i += 1
            return cur
        return power(base, exp)
    return node


def _square_of_named(node, name):
    node = simplify(node)
    if node[0] == "pow" and same(node[2], num(2)) and node[1][0] == "fn" and node[1][1] == name:
        return node[1][2]
    return None


def _square_info(node):
    node = simplify(node)
    if node[0] == "pow" and same(node[2], num(2)) and node[1][0] == "fn":
        name = node[1][1]
        if name in ("sin", "cos", "tan", "sec", "cot", "cosec"):
            return name, node[1][2]
    return None


def _scaled_pythagorean_value(coeff1, rest1, coeff2, rest2):
    info1 = _square_info(rest1)
    info2 = _square_info(rest2)
    if info1 is None or info2 is None:
        return None
    name1, arg1 = info1
    name2, arg2 = info2
    if not same(arg1, arg2):
        return None
    if ((name1 == "sin" and name2 == "cos") or (name1 == "cos" and name2 == "sin")) and same(coeff1, coeff2):
        return coeff1
    if ((name1 == "sec" and name2 == "tan") or (name1 == "tan" and name2 == "sec")) and same(coeff1, neg(coeff2)):
        return coeff1 if name1 == "sec" else coeff2
    if ((name1 == "cosec" and name2 == "cot") or (name1 == "cot" and name2 == "cosec")) and same(coeff1, neg(coeff2)):
        return coeff1 if name1 == "cosec" else coeff2
    return None


def _scaled_constant_square_value(coeff1, rest1, coeff2, rest2):
    if is_one(rest1):
        const_coeff = coeff1
        square_coeff = coeff2
        square = _square_info(rest2)
    elif is_one(rest2):
        const_coeff = coeff2
        square_coeff = coeff1
        square = _square_info(rest1)
    else:
        return None
    if square is None or not same(square_coeff, neg(const_coeff)):
        return None
    name, arg = square
    if name == "sin":
        return mul([const_coeff, power(fn("cos", arg), num(2))])
    if name == "cos":
        return mul([const_coeff, power(fn("sin", arg), num(2))])
    if name == "tan":
        return mul([const_coeff, power(fn("sec", arg), num(2))])
    if name == "cot":
        return mul([const_coeff, power(fn("cosec", arg), num(2))])
    return None


def _pythagorean_add_once(node):
    node = simplify(node)
    if node[0] != "add":
        return node
    terms = list(flat(node, "add"))
    used = [False] * len(terms)
    out = []
    changed = False
    i = 0
    while i < len(terms):
        if used[i]:
            i += 1
            continue
        coeff_i, rest_i = _split_num_coeff(terms[i])
        matched = False
        j = i + 1
        while j < len(terms):
            if not used[j]:
                coeff_j, rest_j = _split_num_coeff(terms[j])
                value = _scaled_pythagorean_value(coeff_i, rest_i, coeff_j, rest_j)
                if value is None:
                    value = _scaled_constant_square_value(coeff_i, rest_i, coeff_j, rest_j)
                if value is not None:
                    out.append(value)
                    used[i] = True
                    used[j] = True
                    matched = True
                    changed = True
                    break
                if matched:
                    break
            j += 1
        if not matched and not used[i]:
            out.append(terms[i])
            used[i] = True
        i += 1
    if not changed:
        return node
    return add(out)


def trig_reduce(node):
    node = simplify(node)
    kind = node[0]
    if kind in ("num", "sym", "const"):
        return node
    if kind == "fn":
        return fn(node[1], trig_reduce(node[2]))
    if kind == "pow":
        return power(trig_reduce(node[1]), trig_reduce(node[2]))
    if kind == "div":
        top = trig_reduce(node[1])
        bot = trig_reduce(node[2])
        if top[0] == "fn" and bot[0] == "fn" and same(top[2], bot[2]):
            if top[1] == "sin" and bot[1] == "cos":
                return fn("tan", top[2])
            if top[1] == "cos" and bot[1] == "sin":
                return fn("cot", top[2])
        return div(top, bot)
    if kind == "mul":
        return mul([trig_reduce(item) for item in flat(node, "mul")])
    if kind == "add":
        return _pythagorean_add_once(add([trig_reduce(item) for item in flat(node, "add")]))
    return node


def canonical_form(node):
    cur = simplify(node)
    i = 0
    while i < 4:
        nxt = simplify(trig_reduce(expand_small(cur)))
        if same(nxt, cur):
            return nxt
        cur = nxt
        i += 1
    return cur


def _collect_symbols(node, out):
    kind = node[0]
    if kind == "sym":
        if node[1] not in out:
            out.append(node[1])
        return
    if kind in ("num", "const"):
        return
    if kind == "fn":
        _collect_symbols(node[2], out)
        return
    if kind in ("pow", "div"):
        _collect_symbols(node[1], out)
        _collect_symbols(node[2], out)
        return
    for child in node[1]:
        _collect_symbols(child, out)


def numeric_eval(node, env):
    try:
        kind = node[0]
        if kind == "num":
            return float(node[1]) / float(node[2])
        if kind == "sym":
            return env.get(node[1], 0.0)
        if kind == "const":
            if node[1] == "pi":
                return math.pi
            if node[1] == "e":
                return math.e
            return None
        if kind == "add":
            total = 0.0
            for child in flat(node, "add"):
                v = numeric_eval(child, env)
                if v is None:
                    return None
                total += v
            return total
        if kind == "mul":
            total = 1.0
            for child in flat(node, "mul"):
                v = numeric_eval(child, env)
                if v is None:
                    return None
                total *= v
            return total
        if kind == "div":
            a = numeric_eval(node[1], env)
            b = numeric_eval(node[2], env)
            if a is None or b is None or abs(b) < 1e-12:
                return None
            return a / b
        if kind == "pow":
            a = numeric_eval(node[1], env)
            b = numeric_eval(node[2], env)
            if a is None or b is None:
                return None
            return a ** b
        if kind == "fn":
            v = numeric_eval(node[2], env)
            if v is None:
                return None
            name = node[1]
            if name == "sin":
                return math.sin(v)
            if name == "cos":
                return math.cos(v)
            if name == "tan":
                return math.tan(v)
            if name == "sec":
                c = math.cos(v)
                if abs(c) < 1e-12:
                    return None
                return 1.0 / c
            if name == "cosec":
                s = math.sin(v)
                if abs(s) < 1e-12:
                    return None
                return 1.0 / s
            if name == "cot":
                t = math.tan(v)
                if abs(t) < 1e-12:
                    return None
                return 1.0 / t
            if name == "exp":
                return math.exp(v)
            if name == "log":
                if v <= 0:
                    return None
                return math.log(v)
            if name == "sqrt":
                if v < 0:
                    return None
                return math.sqrt(v)
            if name == "abs":
                return abs(v)
            if name == "asin":
                if v < -1 or v > 1:
                    return None
                return math.asin(v)
            if name == "acos":
                if v < -1 or v > 1:
                    return None
                return math.acos(v)
            if name == "atan":
                return math.atan(v)
    except Exception:
        return None
    return None


def equivalent_exact(a, b, var="x"):
    if same(simplify(a), simplify(b)):
        return True
    diff = canonical_form(add([a, neg(b)]))
    return is_zero(diff) or same(diff, num(0))


def equivalent(a, b, var="x"):
    if equivalent_exact(a, b, var):
        return True
    if math is None:
        return False
    names = []
    _collect_symbols(a, names)
    _collect_symbols(b, names)
    samples = (-2.3, -1.4, -0.7, 0.4, 1.1, 2.2)
    good = 0
    for base in samples:
        env = {}
        i = 0
        while i < len(names):
            env[names[i]] = base + 0.37 * i
            i += 1
        av = numeric_eval(a, env)
        bv = numeric_eval(b, env)
        if av is None or bv is None:
            continue
        if abs(av - bv) > 1e-6 * (1.0 + abs(av) + abs(bv)):
            return False
        good += 1
    return good >= 3


def equivalence_lines(a, b, left_name="Expr1", right_name="Expr2"):
    left = canonical_form(a)
    right = canonical_form(b)
    if not equivalent_exact(left, right):
        return None
    diff = canonical_form(add([left, neg(right)]))
    return [
        left_name + " -> " + format_expr(left),
        right_name + " -> " + format_expr(right),
        "Difference -> " + format_expr(diff),
        "Answer: Equivalent",
    ]


def rewrite_variants(node, purpose=None):
    """Offer a short list of equivalent shapes for proof/transform attempts."""
    variants = [simplify(node)]
    canon = canonical_form(node)
    if not same(canon, variants[0]):
        variants.append(canon)
    trig = integrate_trig_conjugate_ratio(node, "x")
    if trig is not None:
        variants.append(trig[1])
    return variants


def differentiate(node, var="x"):
    raise NotImplementedError("casio_core.differentiate is supplied by program adapters")


def integrate(node, var="x", mode="auto", forced_u=None):
    """Shared integration dispatch for patterns useful to more than one program."""
    if mode in ("auto", "1", "sub", "4"):
        out = integrate_reciprocal_exp(node, var, forced_u)
        if out is not None:
            return out
    if mode in ("auto", "1", "trig", "3"):
        out = integrate_trig_conjugate_ratio(node, var)
        if out is not None:
            return out
    return None


def solve_task(program, mode, payload):
    return None
