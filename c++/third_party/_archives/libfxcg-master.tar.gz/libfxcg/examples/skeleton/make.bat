..\..\bin\make.exe %*
